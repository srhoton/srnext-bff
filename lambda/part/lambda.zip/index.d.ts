import { Handler } from 'aws-lambda';
import { AppSyncEvent } from './types';
export declare const handler: Handler<AppSyncEvent, unknown>;
//# sourceMappingURL=index.d.ts.map