import { AppSyncEvent } from './types';
export declare const handler: (event: AppSyncEvent) => Promise<unknown>;
//# sourceMappingURL=index.d.ts.map